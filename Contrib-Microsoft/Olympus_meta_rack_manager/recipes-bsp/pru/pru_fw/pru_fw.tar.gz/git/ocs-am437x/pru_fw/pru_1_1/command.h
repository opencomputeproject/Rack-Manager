// Copyright (C) Microsoft Corporation. All rights reserved.
//
// This program is free software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

#include <stdio.h>

#define PACK( __Declaration__ ) __Declaration__ __attribute__((__packed__))

#define SHAREDATA ((volatile uint16_t *)(0x10000))

#define RESERVED 0x00

#define GET_THROTTLE_LIMIT		0x01
#define SET_THROTTLE_LIMIT 		0x02
#define GET_PWR_READING			0x03
#define GET_PHASE_PWR_READING	0x04	
#define GET_PHASE_I_READING		0x05
#define GET_PHASE_V_READING		0x06
#define SET_THROTTLE			0x07
#define GET_THROTTLE			0x08
#define CONTROL_THROTTLE		0x09
#define SET_OFFSET				0x0A
#define GET_OFFSET				0x0B
#define SET_GAIN				0x0C
#define GET_GAIN				0x0D
#define PHASE_STATUS			0x20
#define MAX_PWR_STAT			0x21
#define CLEAR_MAX_PWR_STAT		0x22
#define CLEAR_STATUS			0x23
#define FIRMWARE_VERSION		0x30

typedef enum 
{
	STATUS_SUCCESS = 0,
	STATUS_INVALID_CMD = 1,
	STATUS_RESOURCE = 2,
	STATUS_UNKNOWN	= 3
} status_t;

PACK(typedef struct {
	uint8_t cmd			:8;
	uint8_t seq			:6;
	uint8_t reserved	:2;
	uint8_t data[4];
}) request_t;

PACK(typedef struct {
	uint8_t cmd			:8;
	uint8_t seq			:6;
	uint8_t status		:2;
	uint8_t data[32];
}) response_t;
