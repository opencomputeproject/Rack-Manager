// Copyright (C) Microsoft Corporation. All rights reserved.
//
// This program is free software; you can redistribute it
// and/or modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.

#include <stdint.h>
#include <pru_cfg.h>
#include <pru_ctrl.h>
#include "resource_table_empty.h"
#include <pru_intc.h>
#include <pru_iep.h>
#include "rsc_table_pru.h"

#include "main_power.h"

#define testUNKNOWN_FAULT 0
#define testLOGIC_ERROR  0

/* Mapping Constant Table (CT) registers to variables */
volatile far uint32_t CT_MCSPI0 __attribute__((cregister("MCSPI0", near), peripheral));

#ifndef PRU_SRAM
#define PRU_SRAM __far __attribute__((cregister("PRU_SHAREDMEM", near)))
#endif

PRU_SRAM volatile uint16_t averageVs1TSR[3];//Address:0x10000,0x10002,0x10004,
PRU_SRAM volatile uint16_t averageIs1TSR[3];//Address:0x10006,0x10008,0x1000a
PRU_SRAM volatile uint16_t averageVs2TSR[3];//Address:0x1000c,0x1000e,0x10010
PRU_SRAM volatile uint16_t averageIs2TSR[3];//Address:0x10012,0x10014,0x10016
PRU_SRAM volatile uint16_t vs1PowerTSR[3];//Address:0x10018,0x1001a,0x101c,
PRU_SRAM volatile uint16_t vs2PowerTSR[3];//Address:0x101e,0x1020,0x1022

PRU_SRAM volatile uint16_t maxTotalPowerTSR;//Address:0x10024,
PRU_SRAM volatile uint16_t maxVs1TSR[3];//Address:0x10026,0x1028,0x102A,
PRU_SRAM volatile uint16_t maxIs1TSR[3];//Address:0x1002C,0x1002e,0x10030,
PRU_SRAM volatile uint16_t maxVs2TSR[3];//Address:0x10032,0x10034,0x10036
PRU_SRAM volatile uint16_t maxIs2TSR[3];//Address:0x10038,0x1003a,0x1003c

PRU_SRAM volatile uint16_t StatusFeed1TSR;//Address:0x1003e,
PRU_SRAM volatile uint16_t StatusFeed2TSR;//Address:0x10040

PRU_SRAM volatile uint16_t limitCurrentStateTSR;//Address:0x10042
PRU_SRAM volatile uint16_t firmeareVersionTSR;//Address:0x10044
PRU_SRAM volatile uint32_t totalPowerTSR;//Address:0x10046

PRU_SRAM volatile uint16_t throttleLimitValueFSR;//Address:0x1004a
PRU_SRAM volatile uint16_t limitThrottleEnableFSR;//Address:0x1004c
PRU_SRAM volatile uint16_t controlStateFSR;//Address:0x1004e

PRU_SRAM volatile uint16_t vsGainFSR[6];//Address:0x10050,
PRU_SRAM volatile int16_t vsOffsetFSR[6];//Address:0x1005C,
PRU_SRAM volatile uint16_t isGainFSR[6];//Address:0x10068,
PRU_SRAM volatile int16_t isOffsetFSR[6];//Address:0x10074,

PRU_SRAM volatile uint16_t clearMaxFSR;//Address:0x10080,

PRU_SRAM volatile uint16_t clearFeed1StatusFSR;//Address:0x10082,
PRU_SRAM volatile uint16_t clearFeed2StatusFSR;//Address:0x10084,
PRU_SRAM volatile uint16_t pruSignalStateTSR;//Address:0x10086,
PRU_SRAM volatile uint16_t DCThrottleFSR;//Address:0x10088
PRU_SRAM volatile uint16_t DCThrottleStateTSR;//Address:0x1008A
PRU_SRAM volatile uint16_t callThrottleActiveFSR;//Address:0x1008C


PRU_SRAM volatile uint16_t test[40];
/* NOTE:  Allocating shared_freq_x to PRU Shared Memory means that other PRU cores on
 *        the same subsystem must take care not to allocate data to that memory.
 *	 	  Users also cannot rely on where in shared memory these variables are placed
 *        so accessing them from another PRU core or from the ARM is an undefined behavior.
 */
 
//--- Output/Input PRU IO ---/
volatile register uint32_t __R30;
volatile register uint32_t __R31; 

//--- Define Struct ---/
PMDUInfo_Struct		PMDUInfo;
tCalibration		calibrFeedA_V1, calibrFeedA_V2, calibrFeedA_V3, calibrFeedA_I1, calibrFeedA_I2, calibrFeedA_I3;
tCalibration		calibrFeedB_V1, calibrFeedB_V2, calibrFeedB_V3, calibrFeedB_I1, calibrFeedB_I2, calibrFeedB_I3;
FeedAStatus_Struct 	FeedAPhaseStatus;
FeedBStatus_Struct 	FeedBPhaseStatus;

//--- Define Global Parameter ---//
volatile uint32_t *ptr_cmADC;


unsigned long ADCrawData[6];
unsigned char ADCrawDataID;

signed long ADCreviseSenseVS1[3];
signed long ADCreviseSenseVS2[3];
signed long ADCreviseSenseIS1[3];
signed long ADCreviseSenseIS2[3];

signed long vs1Integration[3];
signed long vs2Integration[3];

signed long is1Integration[3];
signed long is2Integration[3];

signed long averageVs1[3];
signed long averageVs2[3];
signed long averageIs1[3];
signed long averageIs2[3];
//signed long totalIs;

unsigned int vs1Power[4];
unsigned int vs2Power[4];
long totalPower;

//unsigned int throttleCounter;
//unsigned int throttleCounterR;

unsigned char limitThrottleEnable;
unsigned int throttleLimitValue;
unsigned char controlState ;
unsigned char limitCurrentState = 1;
unsigned char DCThrottle;
unsigned char DCThrottleState = 1;
unsigned char callThrottleActive;

//--- ???remove ---
unsigned int slowAvgCounter;

unsigned char enProtect = 0;

uint16_t counterIntegrator = 0;

inline void initialVariable()
{
//   initial ADC by PRU
	uint32_t addrPrcmCmClkselADC1Clk = 0x44DF424C;// PRCM_CM_CLKSEL_ADC1_CLK Register  prcmCmClkselADC1Clk
	uint32_t prcmCmClkselADC1Clk = 0x00;//Select Main Crystal clock as ADC1 clock
	*(volatile uint32_t *) addrPrcmCmClkselADC1Clk = prcmCmClkselADC1Clk;

	uint32_t addrADC1CLKCTRL = 0x44DF8A30;// PRCM_CM_PER_ADC1_CLKCTRL Register
	uint32_t ADC1CLKCTRL = 0x02;// Module is explicitly enabled
	*(volatile uint32_t *) addrADC1CLKCTRL = ADC1CLKCTRL;

	uint32_t addrADC1CTRL = 0x4834C040;//. ADC1_CTRL: bypass the PreAmplifier, power down PreAmp,AFE is powered up (default)
	uint32_t ADC1CTRL = 0x66;    // Enables Simultaneous,Store the channel ID tag, (ADC1 module enable after setting setp ,ADC1CTRL = 0x67),
	*(volatile uint32_t *) addrADC1CTRL = ADC1CTRL; //Matt_PRU

	uint32_t addrForceIdle = 0x4834C010;//00 -> ForceIdle (always acknowledges).// Matt_PRU
	uint32_t regValForceIdle = 0x00;
	 *(volatile uint32_t *) addrForceIdle = regValForceIdle;

	uint32_t addrADC1ClkB = 0x4834C04C;
	uint32_t regValADC1ClkB = 0x07;
	*(volatile uint32_t *) addrADC1ClkB = regValADC1ClkB;

	uint32_t addrADC1StepConfig1 = 0x4834C064;//   ADC1_STEPCONFIG1 Register
	uint32_t ADC1StepConfig1 = 0x11;     // stored in FIFO0, Single Ended,SEL_RFM = VSSA,SEL_INP=Channel 1, SEL_INM = Channel 1,SEL_RFP= 000 - VDDA,SWIPE Feature is off, AVERAGING = no,Software enabled, continuous.
	*(volatile uint32_t *) addrADC1StepConfig1 = ADC1StepConfig1; //Matt_PRU

	uint32_t addrADC1StepConfig2 = 0x4834C06C;//   ADC1_STEPCONFIG2 Register
	uint32_t ADC1StepConfig2 = 0x80011;  // stored in FIFO0, Single Ended,SEL_RFM = VSSA,SEL_INP=Channel 2, SEL_INM =  1,SEL_RFP= 000 - VDDA,SWIPE Feature is off, AVERAGING = no,Software enabled, continuous.
	*(volatile uint32_t *) addrADC1StepConfig2 = ADC1StepConfig2; //Matt_PRU

	uint32_t addrADC1StepConfig3 = 0x4834C074;//   ADC1_STEPCONFIG3 Register
	uint32_t ADC1StepConfig3 = 0x100011; // stored in FIFO0, Single Ended,SEL_RFM = VSSA,SEL_INP=Channel 3, SEL_INM =  1,SEL_RFP= 000 - VDDA,SWIPE Feature is off, AVERAGING = no,Software enabled, continuous.
	*(volatile uint32_t *) addrADC1StepConfig3 = ADC1StepConfig3; //Matt_PRU

	uint32_t addrADC1StepConfig4 = 0x4834C07C;//   ADC1_STEPCONFIG4 Register
	uint32_t ADC1StepConfig4 = 0x180011; // stored in FIFO0, Single Ended,SEL_RFM = VSSA,SEL_INP=Channel 4, SEL_INM =  1,SEL_RFP= 000 - VDDA,SWIPE Feature is off, AVERAGING = no,Software enabled, continuous.
	*(volatile uint32_t *) addrADC1StepConfig4 = ADC1StepConfig4; //Matt_PRU

	uint32_t addrADC1StepConfig5 = 0x4834C084;//   ADC1_STEPCONFIG5 Register
	uint32_t ADC1StepConfig5 = 0x200011; // stored in FIFO0, Single Ended,SEL_RFM = VSSA,SEL_INP=Channel 5, SEL_INM =  1,SEL_RFP= 000 - VDDA,SWIPE Feature is off, AVERAGING = no,Software enabled, continuous.
	*(volatile uint32_t *) addrADC1StepConfig5 = ADC1StepConfig5; //Matt_PRU

	uint32_t addrADC1StepConfig6 = 0x4834C08C;//   ADC1_STEPCONFIG6 Register
	uint32_t ADC1StepConfig6 = 0x280011; // stored in FIFO0, Single Ended,SEL_RFM = VSSA,SEL_INP=Channel 6, SEL_INM =  1,SEL_RFP= 000 - VDDA,SWIPE Feature is off, AVERAGING = no,Software enabled, continuous.
	*(volatile uint32_t *) addrADC1StepConfig6 = ADC1StepConfig6; //Matt_PRU

	uint32_t addrADC1STEPENB = 0x4834C054;//  ADC1_STEPEN Register
	uint32_t ADC1STEPENB = 0x7E; //enable step1 ~ step8
	*(volatile uint32_t *) addrADC1STEPENB = ADC1STEPENB; //Matt_PRU

	uint32_t addrADC1IrqenSet = 0x4834C02C;//  ADC1_STEPEN Register
	uint32_t ADC1IrqenSet = 0x02; //END_OF_SEQUENCE ,Write 1: Enable interrupt.
	*(volatile uint32_t *) addrADC1IrqenSet = ADC1IrqenSet; //Matt_PRU

	uint32_t addrADC1CTRLBB = 0x4834C040;//. ADC1_CTRL: bypass the PreAmplifier, power down PreAmp,AFE is powered up (default)
	uint32_t ADC1CTRLBB = 0x67;    // Enables Simultaneous,Store the channel ID tag, (ADC1 module enable after setting setp ,ADC1CTRL = 0x67),
	*(volatile uint32_t *) addrADC1CTRLBB = ADC1CTRLBB; //Matt_PRU


	vs1Integration[0] = 0;
	vs1Integration[1] = 0;
	vs1Integration[2] = 0;

	vs2Integration[0] = 0;
	vs2Integration[1] = 0;
	vs2Integration[2] = 0;

	is1Integration[0] = 0;
	is1Integration[1] = 0;
	is1Integration[2] = 0;

	is2Integration[0] = 0;
	is2Integration[1] = 0;
	is2Integration[2] = 0;

	StatusFeed1TSR = 0;
	StatusFeed2TSR = 0;

	firmeareVersionTSR = 0x0007;
	totalPowerTSR = 0;

	throttleLimitValueFSR = 10604;
	limitThrottleEnableFSR = 0;
	pruSignalStateTSR = 0;
	controlStateFSR = 0;
	DCThrottleFSR = 0;

	clearMaxFSR = 0;

    //--- Initial the Gain & Offset ---
	vsGainFSR[0] = 16384;
  	vsGainFSR[1] = 16384;
  	vsGainFSR[2] = 16384;
  	vsGainFSR[3] = 16384;
  	vsGainFSR[4] = 16384;
  	vsGainFSR[5] = 16384;


  	vsOffsetFSR[0] = 0;
  	vsOffsetFSR[1] = 0;
  	vsOffsetFSR[2] = 0;
  	vsOffsetFSR[3] = 0;
  	vsOffsetFSR[4] = 0;
  	vsOffsetFSR[5] = 0;


  	isGainFSR[0] = 16384;
  	isGainFSR[1] = 16384;
  	isGainFSR[2] = 16384;
  	isGainFSR[3] = 16384;
  	isGainFSR[4] = 16384;
  	isGainFSR[5] = 16384;

  	isOffsetFSR[0] = 0;
  	isOffsetFSR[1] = 0;
  	isOffsetFSR[2] = 0;
  	isOffsetFSR[3] = 0;
  	isOffsetFSR[4] = 0;
  	isOffsetFSR[5] = 0;

	//--- Initial the Phase Status --- 
	FeedAPhaseStatus.all = 0x00;
	FeedBPhaseStatus.all = 0x00;

  	//--- Status & Protect ---

 // 	LimitThrottleEnable = 0;
 // 	throttleLimit = 10720;
 // 	ControlState = 0;
 // 	limitCurrentState = 0;
 // 	throttleCounter = 0;
	//throttleCounterR = 0;

	slowAvgCounter = 0;
}

inline void readRawValue(void)
{
	static uint8_t indexCountF1 = 0;
	static signed int ADCrawFeedAVR, ADCrawFeedAVS, ADCrawFeedAVT;
	static signed int ADCrawFeedBVR, ADCrawFeedBVS, ADCrawFeedBVT;
	static signed int ADCrawFeedAIR, ADCrawFeedAIS, ADCrawFeedAIT;
	static signed int ADCrawFeedBIR, ADCrawFeedBIS, ADCrawFeedBIT;
	
	calibrFeedA_V1.gain = vsGainFSR[0];
	calibrFeedA_V2.gain = vsGainFSR[1];
	calibrFeedA_V3.gain = vsGainFSR[2];
	calibrFeedB_V1.gain = vsGainFSR[3];
	calibrFeedB_V2.gain = vsGainFSR[4];
	calibrFeedB_V3.gain = vsGainFSR[5];

	calibrFeedA_V1.offset = (vsOffsetFSR[0] & 0x8000) ? (-(vsOffsetFSR[0] & 0x7FFF)) : vsOffsetFSR[0];
	calibrFeedA_V2.offset = (vsOffsetFSR[1] & 0x8000) ? (-(vsOffsetFSR[1] & 0x7FFF)) : vsOffsetFSR[1];
	calibrFeedA_V3.offset = (vsOffsetFSR[2] & 0x8000) ? (-(vsOffsetFSR[2] & 0x7FFF)) : vsOffsetFSR[2];
	calibrFeedB_V1.offset = (vsOffsetFSR[3] & 0x8000) ? (-(vsOffsetFSR[3] & 0x7FFF)) : vsOffsetFSR[3];
	calibrFeedB_V2.offset = (vsOffsetFSR[4] & 0x8000) ? (-(vsOffsetFSR[4] & 0x7FFF)) : vsOffsetFSR[4];
	calibrFeedB_V3.offset = (vsOffsetFSR[5] & 0x8000) ? (-(vsOffsetFSR[5] & 0x7FFF)) : vsOffsetFSR[5];

	calibrFeedA_I1.gain = isGainFSR[0];
	calibrFeedA_I2.gain = isGainFSR[1];
	calibrFeedA_I3.gain = isGainFSR[2];
	calibrFeedB_I1.gain = isGainFSR[3];
	calibrFeedB_I2.gain = isGainFSR[4];
	calibrFeedB_I3.gain = isGainFSR[5];

	calibrFeedA_I1.offset = (isOffsetFSR[0] & 0x8000) ? (-(isOffsetFSR[0] & 0x7FFF)) : isOffsetFSR[0];
	calibrFeedA_I2.offset = (isOffsetFSR[1] & 0x8000) ? (-(isOffsetFSR[1] & 0x7FFF)) : isOffsetFSR[1];
	calibrFeedA_I3.offset = (isOffsetFSR[2] & 0x8000) ? (-(isOffsetFSR[2] & 0x7FFF)) : isOffsetFSR[2];
	calibrFeedB_I1.offset = (isOffsetFSR[3] & 0x8000) ? (-(isOffsetFSR[3] & 0x7FFF)) : isOffsetFSR[3];
	calibrFeedB_I2.offset = (isOffsetFSR[4] & 0x8000) ? (-(isOffsetFSR[4] & 0x7FFF)) : isOffsetFSR[4];
	calibrFeedB_I3.offset = (isOffsetFSR[5] & 0x8000) ? (-(isOffsetFSR[5] & 0x7FFF)) : isOffsetFSR[5];

	ptr_cmADC = ADC1Fifodata;

	for (indexCountF1 = 0; indexCountF1 < 6; indexCountF1++)
	{
		ADCrawData[indexCountF1] = *(ptr_cmADC+indexCountF1);

		ADCrawDataID	= (ADCrawData[indexCountF1]>>28) & 0x0000000F;
		
#if testLOGIC_ERROR
		if(limitThrottleEnable == 0)
		{
			if(ADCrawDataID == 0x00)
				ADCrawDataID--;
		}
#endif 			
		switch (ADCrawDataID)
		{
			case 0x00:
				ADCrawFeedAVR = (ADCrawData[indexCountF1] >> 16) & 0x0FFF;
				ADCreviseSenseVS1[0] = ADCrawFeedAVR << 3;

				ADCrawFeedAIR = ADCrawData[indexCountF1] & 0x00FFF;
				ADCreviseSenseIS1[0] = ADCrawFeedAIR  <<3;
				
				//--- FeedA/B LOGIC_ERROR [Bit2]---	
				if(clearFeed1StatusFSR == 1)
				{
					FeedAPhaseStatus.bits.LOGIC_ERROR = FALSE;
					FeedBPhaseStatus.bits.LOGIC_ERROR = FALSE;
				}	
			break;

			case 0x01:
				ADCrawFeedAVS = (ADCrawData[indexCountF1] >> 16)& 0x0FFF ;
				ADCreviseSenseVS1[1] = ADCrawFeedAVS <<3;

				ADCrawFeedAIS = ADCrawData[indexCountF1] & 0x00FFF;
				ADCreviseSenseIS1[1] = ADCrawFeedAIS <<3;

			break;

			case 0x02:
				ADCrawFeedAVT = (ADCrawData[indexCountF1] >> 16)& 0x0FFF;
				ADCreviseSenseVS1[2] = ADCrawFeedAVT <<3;

				ADCrawFeedAIT = ADCrawData[indexCountF1] & 0x00FFF;
				ADCreviseSenseIS1[2] = ADCrawFeedAIT <<3;

			break;

			case 0x03:
				ADCrawFeedBVR = (ADCrawData[indexCountF1] >> 16)& 0x0FFF;
				ADCreviseSenseVS2[0] = ADCrawFeedBVR <<3;

				ADCrawFeedBIR = ADCrawData[indexCountF1] & 0x00FFF;
				ADCreviseSenseIS2[0] = ADCrawFeedBIR <<3;

			break;

			case 0x04:
				ADCrawFeedBVS = (ADCrawData[indexCountF1] >> 16)& 0x0FFF;
				ADCreviseSenseVS2[1] = ADCrawFeedBVS <<3;

				ADCrawFeedBIS = ADCrawData[indexCountF1] & 0x00FFF;
				ADCreviseSenseIS2[1] = ADCrawFeedBIS <<3;
			break;

			case 0x05:
				ADCrawFeedBVT = (ADCrawData[indexCountF1] >> 16)& 0x0FFF;
				ADCreviseSenseVS2[2] = ADCrawFeedBVT <<3;

				ADCrawFeedBIT = ADCrawData[indexCountF1] & 0x00FFF;
				ADCreviseSenseIS2[2] = ADCrawFeedBIT <<3;
				
			break;

			default:
				//--- FeedA/B LOGIC_ERROR [Bit2]---
				FeedAPhaseStatus.bits.LOGIC_ERROR = TRUE;
				FeedBPhaseStatus.bits.LOGIC_ERROR = TRUE;			
			break;

		}

	}

	//--- FeedA Phase1 Voltage ---
	ADCreviseSenseVS1[0] -= middleSenseV;
	if(ADCreviseSenseVS1[0] < 0) 
		ADCreviseSenseVS1[0] = -ADCreviseSenseVS1[0];	

	ADCreviseSenseVS1[0] = (int)((long)ADCreviseSenseVS1[0] * calibrFeedA_V1.gain >>14)+ calibrFeedA_V1.offset;

	//--- FeedA Phase2 Voltage ---
	ADCreviseSenseVS1[1] -= middleSenseV;
	if(ADCreviseSenseVS1[1] < 0) 
		ADCreviseSenseVS1[1] = -ADCreviseSenseVS1[1];		
	ADCreviseSenseVS1[1] = (int)((long)ADCreviseSenseVS1[1] * calibrFeedA_V2.gain >>14)+ calibrFeedA_V2.offset;

	//--- FeedA Phase3 Voltage ---
	ADCreviseSenseVS1[2] -= middleSenseV;
	if(ADCreviseSenseVS1[2] < 0) 
		ADCreviseSenseVS1[2] = -ADCreviseSenseVS1[2];		
	ADCreviseSenseVS1[2] = (int)((long)ADCreviseSenseVS1[2] * calibrFeedA_V3.gain >>14)+ calibrFeedA_V3.offset;


	//--- FeedA Phase1 Current ---
	ADCreviseSenseIS1[0] -= middleSenseV;
	if(ADCreviseSenseIS1[0] < 0) 
		ADCreviseSenseIS1[0] = -ADCreviseSenseIS1[0];	
	ADCreviseSenseIS1[0] = (int)((long)ADCreviseSenseIS1[0] * calibrFeedA_I1.gain>>14) + calibrFeedA_I1.offset;

	//--- FeedA Phase2 Current ---
	ADCreviseSenseIS1[1] -= middleSenseV;
	if(ADCreviseSenseIS1[1] < 0) 
		ADCreviseSenseIS1[1] = -ADCreviseSenseIS1[1];		
	ADCreviseSenseIS1[1] = (int)((long)ADCreviseSenseIS1[1] * calibrFeedA_I2.gain >> 14)+ calibrFeedA_I2.offset;

	//--- FeedA Phase3 Current ---
	ADCreviseSenseIS1[2] -= middleSenseV;
	if(ADCreviseSenseIS1[2] < 0) 
		ADCreviseSenseIS1[2] = -ADCreviseSenseIS1[2];		
	ADCreviseSenseIS1[2] = (int)((long)ADCreviseSenseIS1[2] * calibrFeedA_I3.gain >> 14)+ calibrFeedA_I3.offset;

	//--- FeedB Phase1 Voltage ---
	ADCreviseSenseVS2[0] -= middleSenseV;
	if(ADCreviseSenseVS2[0] < 0) 
		ADCreviseSenseVS2[0] = -ADCreviseSenseVS2[0];		
	ADCreviseSenseVS2[0] = (int)((long)ADCreviseSenseVS2[0] * calibrFeedB_V1.gain >> 14)+ calibrFeedB_V1.offset;

	//--- FeedB Phase2 Voltage ---
	ADCreviseSenseVS2[1] -= middleSenseV;
	if(ADCreviseSenseVS2[1] < 0) 
		ADCreviseSenseVS2[1] = -ADCreviseSenseVS2[1];	
	ADCreviseSenseVS2[1] = (int)((long)ADCreviseSenseVS2[1] * calibrFeedB_V2.gain >> 14)+ calibrFeedB_V2.offset;

	//--- FeedB Phase3 Voltage ---
	ADCreviseSenseVS2[2] -= middleSenseV;
	if(ADCreviseSenseVS2[2] < 0) 
		ADCreviseSenseVS2[2] = -ADCreviseSenseVS2[2];		
	ADCreviseSenseVS2[2] = (int)((long)ADCreviseSenseVS2[2] * calibrFeedB_V3.gain >> 14)+ calibrFeedB_V3.offset;

	//--- FeedB Phase1 Current ---
	ADCreviseSenseIS2[0] -= middleSenseV;
	if(ADCreviseSenseIS2[0] < 0) 
		ADCreviseSenseIS2[0] = -ADCreviseSenseIS2[0];		
	ADCreviseSenseIS2[0] = (int)((long)ADCreviseSenseIS2[0] * calibrFeedB_I1.gain >> 14)+ calibrFeedB_I1.offset;

	//--- FeedB Phase2 Current ---
	ADCreviseSenseIS2[1] -= middleSenseV;
	if(ADCreviseSenseIS2[1] < 0) 
		ADCreviseSenseIS2[1] = -ADCreviseSenseIS2[1];	
	ADCreviseSenseIS2[1] = (int)((long)ADCreviseSenseIS2[1] * calibrFeedB_I2.gain >> 14)+ calibrFeedB_I2.offset;

	//--- FeedB Phase3 Current ---
	ADCreviseSenseIS2[2] -= middleSenseV;
	if(ADCreviseSenseIS2[2] < 0) 
		ADCreviseSenseIS2[2] = -ADCreviseSenseIS2[2];		
	ADCreviseSenseIS2[2] = (int)((long)ADCreviseSenseIS2[2] * calibrFeedB_I3.gain >> 14)+ calibrFeedB_I3.offset;
}

inline void vacIacIntegration(void)
{
	static long tempFeedAVR = 0, tempFeedAVS = 0, tempFeedAVT = 0;
	static long tempFeedAIR = 0, tempFeedAIS = 0, tempFeedAIT = 0;
	static long tempFeedBVR = 0, tempFeedBVS = 0, tempFeedBVT = 0;
	static long tempFeedBIR = 0, tempFeedBIS = 0, tempFeedBIT = 0;

	tempFeedAVR = tempFeedAVR + ADCreviseSenseVS1[0];
	tempFeedAVS = tempFeedAVS + ADCreviseSenseVS1[1];
	tempFeedAVT = tempFeedAVT + ADCreviseSenseVS1[2];

	tempFeedAIR = tempFeedAIR + ADCreviseSenseIS1[0];
	tempFeedAIS = tempFeedAIS + ADCreviseSenseIS1[1];
	tempFeedAIT = tempFeedAIT + ADCreviseSenseIS1[2];

	tempFeedBVR = tempFeedBVR + ADCreviseSenseVS2[0];
	tempFeedBVS = tempFeedBVS + ADCreviseSenseVS2[1];
	tempFeedBVT = tempFeedBVT + ADCreviseSenseVS2[2];

	tempFeedBIR = tempFeedBIR + ADCreviseSenseIS2[0];
	tempFeedBIS = tempFeedBIS + ADCreviseSenseIS2[1];
	tempFeedBIT = tempFeedBIT + ADCreviseSenseIS2[2];

	counterIntegrator = counterIntegrator + 1 ;

	if(counterIntegrator >= SAMPLE_CST)
	{
//		__R30 ^= 0x20;
		PMDUInfo.bits.enableCalMaxAvg = TRUE;

		vs1Integration[0] = tempFeedAVR;
		vs1Integration[1] = tempFeedAVS;
		vs1Integration[2] = tempFeedAVT;

		is1Integration[0] = tempFeedAIR;
		is1Integration[1] = tempFeedAIS;
		is1Integration[2] = tempFeedAIT;

		vs2Integration[0] = tempFeedBVR;
		vs2Integration[1] = tempFeedBVS;
		vs2Integration[2] = tempFeedBVT;

		is2Integration[0] = tempFeedBIR;
		is2Integration[1] = tempFeedBIS;
		is2Integration[2] = tempFeedBIT;
		
		tempFeedAVR = 0;
		tempFeedAVS = 0;
		tempFeedAVT = 0;
		tempFeedAIR = 0;
		tempFeedAIS = 0;
		tempFeedAIT = 0;
		tempFeedBVR = 0;
		tempFeedBVS = 0;
		tempFeedBVT = 0;
		tempFeedBIR = 0;
		tempFeedBIS = 0;
		tempFeedBIT = 0;

		counterIntegrator = 0;
	}
}


inline void shortTermMaxAvgCal(void)
{	
	if(PMDUInfo.bits.enableCalMaxAvg == 1)
	{
		slowAvgCounter = slowAvgCounter +1;
		PMDUInfo.bits.enableCalMaxAvg = FALSE;

		averageIs1[0]=(int)(((unsigned long)is1Integration[0]*timeIntegral)>>18);
		averageIs1[1]=(int)(((unsigned long)is1Integration[1]*timeIntegral)>>18);
		averageIs1[2]=(int)(((unsigned long)is1Integration[2]*timeIntegral)>>18);
		averageVs1[0]=(int)(((unsigned long)vs1Integration[0]*timeIntegral)>>18);
		averageVs1[1]=(int)(((unsigned long)vs1Integration[1]*timeIntegral)>>18);
		averageVs1[2]=(int)(((unsigned long)vs1Integration[2]*timeIntegral)>>18);

		averageIs2[0]=(int)(((unsigned long)is2Integration[0]*timeIntegral)>>18);
		averageIs2[1]=(int)(((unsigned long)is2Integration[1]*timeIntegral)>>18);
		averageIs2[2]=(int)(((unsigned long)is2Integration[2]*timeIntegral)>>18);
		averageVs2[0]=(int)(((unsigned long)vs2Integration[0]*timeIntegral)>>18);
		averageVs2[1]=(int)(((unsigned long)vs2Integration[1]*timeIntegral)>>18);
		averageVs2[2]=(int)(((unsigned long)vs2Integration[2]*timeIntegral)>>18);

		averageVs1TSR[0] = averageVs1[0];
		averageVs1TSR[1] = averageVs1[1];
		averageVs1TSR[2] = averageVs1[2];

		averageIs1TSR[0] = averageIs1[0];
		averageIs1TSR[1] = averageIs1[1];
		averageIs1TSR[2] = averageIs1[2];

		averageVs2TSR[0] = averageVs2[0];
		averageVs2TSR[1] = averageVs2[1];
		averageVs2TSR[2] = averageVs2[2];

		averageIs2TSR[0] = averageIs2[0];
		averageIs2TSR[1] = averageIs2[1];
		averageIs2TSR[2] = averageIs2[2];

		//--- Source 1.Maxium Voltage ---
		if(maxVs1TSR[0] < averageVs1[0])
		{
			maxVs1TSR[0] = averageVs1[0];
		}

		if(maxVs1TSR[1] < averageVs1[1])
		{
			maxVs1TSR[1] = averageVs1[1];
		}


		if(maxVs1TSR[2] < averageVs1[2])
		{
			maxVs1TSR[2] = averageVs1[2];
		}

		//--- Source 1.Maxium Current ---
		if(maxIs1TSR[0] < averageIs1[0])
		{
			maxIs1TSR[0] = averageIs1[0];
		}


		if(maxIs1TSR[1] < averageIs1[1])
		{
			maxIs1TSR[1] = averageIs1[1];
		}


		if(maxIs1TSR[2] < averageIs1[2])
		{
			maxIs1TSR[2] = averageIs1[2];
		}

		//--- Source 2.Maxium Voltage ---
		if(maxVs2TSR[0] < averageVs2[0])
		{
			maxVs2TSR[0] = averageVs2[0];
		}


		if(maxVs2TSR[1] < averageVs2[1])
		{
			maxVs2TSR[1] = averageVs2[1];
		}


		if(maxVs2TSR[2] < averageVs2[2])
		{
			maxVs2TSR[2] = averageVs2[2];
		}

		//--- Source 2.Maxium Current ---
		if(maxIs2TSR[0] < averageIs2[0])
		{
			maxIs2TSR[0] = averageIs2[0];
		}

		if(maxIs2TSR[1] < averageIs2[1])
		{
			maxIs2TSR[1] = averageIs2[1];
		}

		if(maxIs2TSR[2] < averageIs2[2])
		{
			maxIs2TSR[2] = averageIs2[2];
		}
		// enable Protect function
		enProtect = 1;
	}
}

inline void calPower(void)
{
	vs1Power[0] = (int)((long)averageVs1[0]*averageIs1[0]>>14);//Q14 = Q14*Q14 >>14
	vs1Power[1] = (int)((long)averageVs1[1]*averageIs1[1]>>14);//Q14 = Q14*Q14 >>14
	vs1Power[2] = (int)((long)averageVs1[2]*averageIs1[2]>>14);//Q14 = Q14*Q14 >>14

	vs1Power[3] = vs1Power[0]+vs1Power[1]+vs1Power[2];

	vs2Power[0] = (int)((long)averageVs2[0]*averageIs2[0]>>14);//Q14 = Q14*Q14 >>14
	vs2Power[1] = (int)((long)averageVs2[1]*averageIs2[1]>>14);//Q14 = Q14*Q14 >>14
	vs2Power[2] = (int)((long)averageVs2[2]*averageIs2[2]>>14);//Q14 = Q14*Q14 >>14

	vs2Power[3] = vs2Power[0] + vs2Power[1]+vs2Power[2];
	totalPower = vs1Power[3] + vs2Power[3];

	vs1PowerTSR[0] = vs1Power[0];
	vs1PowerTSR[1] = vs1Power[1];
	vs1PowerTSR[2] = vs1Power[2];

	vs2PowerTSR[0] = vs2Power[0];
	vs2PowerTSR[1] = vs2Power[1];
	vs2PowerTSR[2] = vs2Power[2];
	totalPowerTSR = totalPower;

	if(maxTotalPowerTSR < totalPower)
	{
		maxTotalPowerTSR = totalPower;
	}

	if(clearMaxFSR == 1)
	{
		clearMaxFSR = 0;

		maxTotalPowerTSR = 0;
		maxVs1TSR[0] = 0;
		maxVs1TSR[1] = 0;
		maxVs1TSR[2] = 0;

		maxIs1TSR[0] = 0;
		maxIs1TSR[1] = 0;
		maxIs1TSR[2] = 0;

		maxVs2TSR[0] = 0;
		maxVs2TSR[1] = 0;
		maxVs2TSR[2] = 0;

		maxIs2TSR[0] = 0;
		maxIs2TSR[1] = 0;
		maxIs2TSR[2] = 0;
	}
}

inline void controlThrottle(void)
{
	static unsigned int throttleCounterR = 0;
	static unsigned int cntDCthrottle = 0;
	static unsigned char onetime = 1;
			
	throttleLimitValue = throttleLimitValueFSR;
	limitThrottleEnable = limitThrottleEnableFSR & 0xFF;
	controlState = controlStateFSR & 0xFF;
	DCThrottle = DCThrottleFSR & 0xFF;
	callThrottleActive = callThrottleActiveFSR & 0xFF;

	//--- Contorl Throttle ---

	if(callThrottleActiveFSR == TRUE)
	{
		callThrottleActiveFSR = FALSE;
		if(controlState == 1)
		{	
			pruSignalStateTSR = 1;	//Assert:High
			__R30 = 0x20;
		}
		else
		{
			pruSignalStateTSR = 0;	//Deassert:Low
			__R30 = 0x00;
		}
	}
	
	//--- Power Limit Throttle ---
	if(limitThrottleEnable == 1)
	{
		if(!limitCurrentState)
		{
			if(totalPower < throttleLimitValue)	
			{
				throttleCounterR = throttleCounterR + 1;	
				if(throttleCounterR > timeLoop1s(0.01))	
				{	
					limitCurrentState = 1; //Default:Low
					throttleCounterR = 0;	

					//--- FeedA/B OC_THROTTLE_LIMIT [Bit1]---
					if(clearFeed1StatusFSR == 1)
					{
						FeedAPhaseStatus.bits.OC_THROTTLE_LIMIT = FALSE;
						FeedBPhaseStatus.bits.OC_THROTTLE_LIMIT = FALSE;
					}
				}
			}
			else
			{
				throttleCounterR = 0;	
			}
		}
		else
		{
			if(totalPower > throttleLimitValue)	
			{
				throttleCounterR = throttleCounterR + 1;
				if(throttleCounterR > timeLoop1s(0.01))
				{
					limitCurrentState = 0; //Active:High
					throttleCounterR = 0;	
					
					//--- FeedA/B OC_THROTTLE_LIMIT [Bit1]---
					FeedAPhaseStatus.bits.OC_THROTTLE_LIMIT = TRUE;
					FeedBPhaseStatus.bits.OC_THROTTLE_LIMIT = TRUE;
				}
			}
			else
			{
				throttleCounterR = 0;
			}
		}
/*		
		if(limitCurrentState == 1)
			__R30 = 0x20;
		else 
			__R30 = 0x00;
*/
	}
	else
	{
	   limitCurrentState = 1;	//Default:Low
	}
	limitCurrentStateTSR = !limitCurrentState;	
	
	//--- DC Throttle ---
	if(DCThrottle == 1)
	{
		if(CT_IEP.TMR_DIGIO_DATA_IN_RAW_bit.DATA_IN_RAW >> 4 == 1)
		{
			cntDCthrottle++;
			if(cntDCthrottle > timeLoop1s(0.01))
			{
				cntDCthrottle = 0;
				DCThrottleState = 1;	//Default:High	
//			__R30 = 0x20;		
			}
		}
		else
		{
			cntDCthrottle++;
			if(cntDCthrottle > timeLoop1s(0.01))
			{
				cntDCthrottle = 0;
				DCThrottleState = 0;   //Active:Low
//				__R30 = 0x00;	
			}
		}		
	}
	else 
	{	
		DCThrottleState = 1;	//Default:High	
	}	
	DCThrottleStateTSR = DCThrottleState;
	
	if(DCThrottleState && limitCurrentState)
	{
		if(controlState == 1)
		{	
			pruSignalStateTSR = 1;	//Deassert:High
			__R30 = 0x20;
		}
		else
		{
			pruSignalStateTSR = 0;	//Assert:Low
			__R30 = 0x00;
		}		
	}
	else 
	{
		__R30 = 0x20;
	}
}

inline void infoPhaseStatus(void)
{
	static uint8_t flgFaultAbit3 = 0, flgFaultBbit3 = 0;
	static unsigned int cntUNKNOWNFeedA = 0, cntUNKNOWNFeedB = 0;
	static unsigned int cntPOWERNEGATEDFeedA = 0, cntPOWERNEGATEDFeedB = 0;
	static unsigned int cntOCPFeedAPhase1 = 0, cntOCPFeedAPhase2 = 0, cntOCPFeedAPhase3 = 0;
	static unsigned int cntOCPFeedBPhase1 = 0, cntOCPFeedBPhase2 = 0, cntOCPFeedBPhase3 = 0;	
	static unsigned int cntOVPFeedAPhase1 = 0, cntOVPFeedAPhase2 = 0, cntOVPFeedAPhase3 = 0;
	static unsigned int cntOVPFeedBPhase1 = 0, cntOVPFeedBPhase2 = 0, cntOVPFeedBPhase3 = 0;	
	static unsigned int cntUVPFeedAPhase1 = 0, cntUVPFeedAPhase2 = 0, cntUVPFeedAPhase3 = 0;
	static unsigned int cntUVPFeedBPhase1 = 0, cntUVPFeedBPhase2 = 0, cntUVPFeedBPhase3 = 0;	

	//--- FeedA POWER NEGATED [Bit0]---
	if(FeedAPhaseStatus.bits.POWER_NEGATED == 1)
	{
		if((averageVs1[0] > inputVQ14(100)) && (averageVs1[1] > inputVQ14(100)) && (averageVs1[2] > inputVQ14(100)))
		{
			//--- Recover ---
			cntPOWERNEGATEDFeedA++;

			if(cntPOWERNEGATEDFeedA > HIGHRECOVERTIME && clearFeed1StatusFSR == 1)
			{
				cntPOWERNEGATEDFeedA = 0;	

				FeedAPhaseStatus.bits.POWER_NEGATED = FALSE;
			}
		}
		else
		{
			cntPOWERNEGATEDFeedA = 0;
		}	
	}
	else 
	{
		if((averageVs1[0] < inputVQ14(100)) || (averageVs1[1] < inputVQ14(100)) || (averageVs1[2] < inputVQ14(100)))
		{
			//--- FAULT ---
			cntPOWERNEGATEDFeedA++;

			if(cntPOWERNEGATEDFeedA > HIGHLIMITTIME)	
			{
				cntPOWERNEGATEDFeedA= 0;	
				FeedAPhaseStatus.bits.POWER_NEGATED = TRUE;
				clearFeed1StatusFSR = 0;
			}
		}
		else
		{
			cntPOWERNEGATEDFeedA = 0;
		}		
	}

	//--- FeedB POWER NEGATED [Bit0]---
	if(FeedBPhaseStatus.bits.POWER_NEGATED == 1)
	{
		if((averageVs2[0] > inputVQ14(100)) && (averageVs2[1] > inputVQ14(100)) && (averageVs2[2] > inputVQ14(100)))
		{
			//--- Recover ---
			cntPOWERNEGATEDFeedB++;

			if(cntPOWERNEGATEDFeedB > HIGHRECOVERTIME && clearFeed1StatusFSR == 1)
			{
				cntPOWERNEGATEDFeedB = 0;	

				FeedBPhaseStatus.bits.POWER_NEGATED = FALSE;
			}
		}
		else
		{
			cntPOWERNEGATEDFeedB = 0;
		}	
	}
	else 
	{
		if((averageVs2[0] < inputVQ14(100)) || (averageVs2[1] < inputVQ14(100)) || (averageVs2[2] < inputVQ14(100)))
		{
			//--- FAULT ---
			cntPOWERNEGATEDFeedB++;

			if(cntPOWERNEGATEDFeedB > HIGHLIMITTIME)	
			{
				cntPOWERNEGATEDFeedB= 0;	
				FeedBPhaseStatus.bits.POWER_NEGATED = TRUE;
				clearFeed1StatusFSR = 0;
			}
		}
		else
		{
			cntPOWERNEGATEDFeedB = 0;
		}		
	}

#if testUNKNOWN_FAULT		
	if(limitThrottleEnable == 0)
	{
		averageVs1[0] = 16385;			
		averageVs1[1] = 16385;
		averageVs1[2] = 16385;
		averageIs1[0] = 16385; 
		averageIs1[1] = 16385;
		averageIs1[2] = 16385;
		vs1Power[0] = 0;
		vs1Power[1] = 0;
		vs1Power[2] = 0;
		
		averageVs2[0] = -1;
		averageVs2[1] = -1;
		averageVs2[2] = -1;
		averageIs2[0] = -1; 
		averageIs2[1] = -1;
		averageIs2[2] = -1;
		vs2Power[0] = 0;
		vs2Power[1] = 0;
		vs2Power[2] = 0;
	}
	else 
	{
		averageVs1[0] = 8192;			
		averageVs1[1] = 8192;
		averageVs1[2] = 8192;
		averageIs1[0] = 4096; 
		averageIs1[1] = 4096;
		averageIs1[2] = 4096;
		vs1Power[0] = 8192;
		vs1Power[1] = 8192;
		vs1Power[2] = 8192;		
		averageVs2[0] = 8192;
		averageVs2[1] = 8192;
		averageVs2[2] = 8192;
		averageIs2[0] = 4096; 
		averageIs2[1] = 4096;
		averageIs2[2] = 4096;
		vs2Power[0] = 4096;
		vs2Power[1] = 4096;
		vs2Power[2] = 4096;
	}
#endif
	
	//--- FeedA UNKNOWN FAULT [bit 3]---
	if(FeedAPhaseStatus.bits.UNKNOWN_FAULT == 1)
	{
		if((0 < averageVs1[0] < FormatQ14) && (0 < averageVs1[1] < FormatQ14) && (0 < averageVs1[2] < FormatQ14) && (0 < averageIs1[0] < FormatQ14) && (0 < averageIs1[1] < FormatQ14) && (0 < averageIs1[2] < FormatQ14) && (0 < vs1Power[0] < FormatQ14) && (0 < vs1Power[1] < FormatQ14) && (0 < vs1Power[2] < FormatQ14))
		{
			//--- Recover ---
			if( clearFeed1StatusFSR == 1)
				FeedAPhaseStatus.bits.UNKNOWN_FAULT = FALSE;		
		}
	}
	else 
	{
		flgFaultAbit3 += (averageIs1[0] > FormatQ14 || averageIs1[0] < 0) ? TRUE : FALSE;
		flgFaultAbit3 += (averageIs1[1] > FormatQ14 || averageIs1[1] < 0) ? TRUE : FALSE;
		flgFaultAbit3 += (averageIs1[2] > FormatQ14 || averageIs1[2] < 0) ? TRUE : FALSE;
		flgFaultAbit3 += (averageVs1[0] > FormatQ14 || averageVs1[0] < 0) ? TRUE : FALSE;	
		flgFaultAbit3 += (averageVs1[1] > FormatQ14 || averageVs1[1] < 0) ? TRUE : FALSE;	
		flgFaultAbit3 += (averageVs1[2] > FormatQ14 || averageVs1[2] < 0) ? TRUE : FALSE;
		if(flgFaultAbit3 > 0)
		{
			//--- FAULT ---
			FeedAPhaseStatus.bits.UNKNOWN_FAULT = TRUE;
			clearFeed1StatusFSR = 0;
			flgFaultAbit3 = 0;
		}		
	}

	//--- FeedB UNKNOWN FAULT [bit 3]---
	if(FeedBPhaseStatus.bits.UNKNOWN_FAULT == 1)
	{
		if((0 < averageVs2[0] < FormatQ14) && (0 < averageVs2[1] < FormatQ14) && (0 < averageVs2[2] < FormatQ14) && (0 < averageIs2[0] < FormatQ14) && (0 < averageIs2[1] < FormatQ14) && (0 < averageIs2[2] < FormatQ14) && (0 < vs2Power[0] < FormatQ14) && (0 < vs2Power[1] < FormatQ14) && (0 < vs2Power[2] < FormatQ14))
		{
			//--- Recover ---
			if(clearFeed1StatusFSR == 1)
				FeedBPhaseStatus.bits.UNKNOWN_FAULT = FALSE;		
		}
	}
	else 
	{
		flgFaultBbit3 += (averageIs2[0] > FormatQ14 || averageIs2[0] < 0) ? TRUE : FALSE;
		flgFaultBbit3 += (averageIs2[1] > FormatQ14 || averageIs2[1] < 0) ? TRUE : FALSE;
		flgFaultBbit3 += (averageIs2[2] > FormatQ14 || averageIs2[2] < 0) ? TRUE : FALSE;
		flgFaultBbit3 += (averageVs2[0] > FormatQ14 || averageVs2[0] < 0) ? TRUE : FALSE;	
		flgFaultBbit3 += (averageVs2[1] > FormatQ14 || averageVs2[1] < 0) ? TRUE : FALSE;	
		flgFaultBbit3 += (averageVs2[2] > FormatQ14 || averageVs2[2] < 0) ? TRUE : FALSE;
		if(flgFaultBbit3 > 0)
		{
			//--- FAULT ---
			FeedBPhaseStatus.bits.UNKNOWN_FAULT = TRUE;
			clearFeed1StatusFSR = 0;
			flgFaultBbit3 = 0;
		}		
	}	
	
	//--- FeedA Phase1 OCP FAULT ---	
	if(FeedAPhaseStatus.bits.PHASE1_I_OC_FAULT == 1)
	{
		if(averageIs1[0] < OCLEVEL)
		{
			//--- Recover ---
			cntOCPFeedAPhase1++;

			if(cntOCPFeedAPhase1 > HIGHRECOVERTIME && clearFeed1StatusFSR == 1)
			{
				cntOCPFeedAPhase1 = 0;	

				FeedAPhaseStatus.bits.PHASE1_I_OC_FAULT = FALSE;
			}
		}
		else
		{
			cntOCPFeedAPhase1 = 0;
		}
	}
	else
	{
		if(averageIs1[0] > OCLEVEL)
		{
			//--- FAULT ---
			cntOCPFeedAPhase1++;

			if(cntOCPFeedAPhase1 > HIGHLIMITTIME)	
			{
				cntOCPFeedAPhase1= 0;	
				FeedAPhaseStatus.bits.PHASE1_I_OC_FAULT = TRUE;
				clearFeed1StatusFSR = 0;
			}
		}
		else
		{
			cntOCPFeedAPhase1 = 0;
		}
	}

	//--- FeedA Phase2 OCP FAULT ---
	if(FeedAPhaseStatus.bits.PHASE2_I_OC_FAULT == 1)
	{
		if(averageIs1[1] < OCLEVEL)
		{
			//--- Recover ---
			cntOCPFeedAPhase2++;

			if( cntOCPFeedAPhase2 > HIGHRECOVERTIME && clearFeed1StatusFSR == 1)
			{
				cntOCPFeedAPhase2 = 0;	
				FeedAPhaseStatus.bits.PHASE2_I_OC_FAULT = FALSE;
			}
		}
		else
		{
			cntOCPFeedAPhase2 = 0;
		}
	}
	else
	{
		if(averageIs1[1] > OCLEVEL)
		{
			//--- FAULT ---
			cntOCPFeedAPhase2++;

			if(cntOCPFeedAPhase2 > HIGHLIMITTIME)	
			{
				cntOCPFeedAPhase2 = 0;

				FeedAPhaseStatus.bits.PHASE2_I_OC_FAULT = TRUE;
				clearFeed1StatusFSR = 0;
			}
		}
		else
		{
			cntOCPFeedAPhase2 = 0;
		}
	}

	//--- FeedA Phase3 OCP FAULT ---
	if(FeedAPhaseStatus.bits.PHASE3_I_OC_FAULT)
	{
		if(averageIs1[2] < OCLEVEL)
		{
			//--- Recover ---
			cntOCPFeedAPhase3++;	

			if(cntOCPFeedAPhase3 > HIGHRECOVERTIME && clearFeed1StatusFSR == 1)
			{
				cntOCPFeedAPhase3 = 0;	
				FeedAPhaseStatus.bits.PHASE3_I_OC_FAULT = FALSE;
			}
		}
		else
		{
			cntOCPFeedAPhase3 = 0;	
		}
	}
	else
	{
		if(averageIs1[2] > OCLEVEL)	
		{
			//--- FAULT ---
			cntOCPFeedAPhase3++;

			if(cntOCPFeedAPhase3 > HIGHLIMITTIME)	
			{
				cntOCPFeedAPhase3 = 0;
					
				FeedAPhaseStatus.bits.PHASE3_I_OC_FAULT = TRUE;
				clearFeed1StatusFSR = 0;
			}
		}
		else
		{
			cntOCPFeedAPhase3 = 0;
		}
	}

	//--- FeedB Phase1 OCP FAULT ---
	if(FeedBPhaseStatus.bits.PHASE1_I_OC_FAULT == 1)
	{
		if(averageIs2[0] < OCLEVEL)	
		{
			//--- Recover ---
			cntOCPFeedBPhase1++;	

			if(cntOCPFeedBPhase1 > HIGHRECOVERTIME  && clearFeed2StatusFSR == 1)	
			{
				cntOCPFeedBPhase1 = 0;	

				FeedBPhaseStatus.bits.PHASE1_I_OC_FAULT = FALSE;
			}
		}
		else
		{
			cntOCPFeedBPhase1 = 0;	
		}
	}
	else
	{
		if(averageIs2[0] > OCLEVEL)
		{
			//--- FAULT ---
			cntOCPFeedBPhase1++;

			if(cntOCPFeedBPhase1 > HIGHLIMITTIME)	
			{
				cntOCPFeedBPhase1 = 0;	

				FeedBPhaseStatus.bits.PHASE1_I_OC_FAULT = TRUE;
				clearFeed2StatusFSR = 0;
			}
		}
		else
		{
			cntOCPFeedBPhase1 = 0;
		}
	}

	//--- FeedB Phase2 OCP FAULT ---
	if(FeedBPhaseStatus.bits.PHASE2_I_OC_FAULT == 1)
	{
		if(averageIs2[1] < OCLEVEL)
		{
			//--- Recover ---
			cntOCPFeedBPhase2++;	

			if(cntOCPFeedBPhase2 > HIGHRECOVERTIME && clearFeed2StatusFSR == 1)	
			{
				cntOCPFeedBPhase2= 0;	

				FeedBPhaseStatus.bits.PHASE2_I_OC_FAULT = FALSE;
			}
		}
		else
		{
			cntOCPFeedBPhase2 = 0;	
		}
	}
	else
	{
		if(averageIs2[1] > OCLEVEL)	
		{
			//--- FAULT ---
			cntOCPFeedBPhase2++;

			if(cntOCPFeedBPhase2 > HIGHLIMITTIME)	
			{
				cntOCPFeedBPhase2 = 0;	

				FeedBPhaseStatus.bits.PHASE2_I_OC_FAULT = TRUE;
				clearFeed2StatusFSR = 0;
			}
		}
		else
		{
			cntOCPFeedBPhase2 = 0;
		}
	}

	//--- FeedB Phase3 OCP FAULT ---
	if(FeedBPhaseStatus.bits.PHASE3_I_OC_FAULT == 1)
	{
		if(averageIs2[2] < OCLEVEL)
		{
			//--- Recover ---
			cntOCPFeedBPhase3++;	

			if(cntOCPFeedBPhase3 > HIGHRECOVERTIME && clearFeed2StatusFSR == 1)	
			{
				cntOCPFeedBPhase3 = 0;	

				FeedBPhaseStatus.bits.PHASE3_I_OC_FAULT = FALSE;
			}
		}
		else
		{
			cntOCPFeedBPhase3 = 0;	
		}
	}
	else
	{
		if(averageIs2[2] > OCLEVEL)
		{
			//--- FAULT ---
			cntOCPFeedBPhase3++;

			if(cntOCPFeedBPhase3 > HIGHLIMITTIME)	
			{
				cntOCPFeedBPhase3 = 0;	

				FeedBPhaseStatus.bits.PHASE3_I_OC_FAULT = TRUE;
				clearFeed2StatusFSR = 0;
			}
		}
		else
		{
			cntOCPFeedBPhase3 = 0;
		}
	}

	//--- FeedA Phase1 OVP FAULT ---
	if(FeedAPhaseStatus.bits.PHASE1_V_OV_FAULT == 1)
	{
		if(averageVs1[0] < OVLEVEL)	
		{
			//--- Recover ---
			cntOVPFeedAPhase1++;	

			if(cntOVPFeedAPhase1 > HIGHRECOVERTIME  && clearFeed1StatusFSR == 1)	
			{
				cntOVPFeedAPhase1 = 0;	

				FeedAPhaseStatus.bits.PHASE1_V_OV_FAULT = FALSE;
			}
		}
		else
		{
			cntOVPFeedAPhase1 = 0;	
		}
	}
	else
	{
		if( averageVs1[0] > OVLEVEL )	
		{
			//--- FAULT ---
			cntOVPFeedAPhase1++;

			if(cntOVPFeedAPhase1 > HIGHLIMITTIME)	
			{
				cntOVPFeedAPhase1 = 0;	

				FeedAPhaseStatus.bits.PHASE1_V_OV_FAULT = TRUE;
				clearFeed1StatusFSR = 0;
			}
		}
		else
		{
			cntOVPFeedAPhase1 = 0;
		}
	}
	//--- FeedA Phase2 OVP FAULT ---
	if(FeedAPhaseStatus.bits.PHASE2_V_OV_FAULT == 1)
	{
		if(averageVs1[1]  < OVLEVEL)	
		{
			//--- Recover ---
			cntOVPFeedAPhase2++;	

			if(cntOVPFeedAPhase2 > HIGHRECOVERTIME && clearFeed1StatusFSR == 1)	
			{
				cntOVPFeedAPhase2 = 0;	

				FeedAPhaseStatus.bits.PHASE2_V_OV_FAULT = FALSE;
			}
		}
		else
		{
			cntOVPFeedAPhase2 = 0;	
		}
	}
	else
	{
		if(averageVs1[1] > OVLEVEL)
		{
			//--- FAULT ---
			cntOVPFeedAPhase2++;

			if(cntOVPFeedAPhase2 > HIGHLIMITTIME)	
			{
				cntOVPFeedAPhase2 = 0;	

				FeedAPhaseStatus.bits.PHASE2_V_OV_FAULT = TRUE;
				clearFeed1StatusFSR = 0;
			}
		}
		else
		{
			cntOVPFeedAPhase2 = 0;
		}
	}
	//--- FeedA Phase3 OVP FAULT ---
	if(FeedAPhaseStatus.bits.PHASE3_V_OV_FAULT == 1)
	{
		if(averageVs1[2] < OVLEVEL && clearFeed1StatusFSR == 1)	
		{
			//--- Recover ---
			cntOVPFeedAPhase3++;	

			if(cntOVPFeedAPhase3 > HIGHRECOVERTIME)	
			{
				cntOVPFeedAPhase3 = 0;	

				FeedAPhaseStatus.bits.PHASE3_V_OV_FAULT = FALSE;
			}
		}
		else
		{
			cntOVPFeedAPhase3 = 0;	
		}
	}
	else
	{
		if(averageVs1[2] > OVLEVEL)	
		{
			//--- FAULT ---
			cntOVPFeedAPhase3++;

			if(cntOVPFeedAPhase3 > HIGHLIMITTIME)	
			{
				cntOVPFeedAPhase3 = 0;	

				FeedAPhaseStatus.bits.PHASE3_V_OV_FAULT = TRUE;
				clearFeed1StatusFSR = 0;
			}
		}
		else
		{
			cntOVPFeedAPhase3 = 0;
		}
	}


	//--- FeedB Phase1 OVP FAULT ---
	if(FeedBPhaseStatus.bits.PHASE1_V_OV_FAULT == 1)
	{
		if(averageVs2[0] < OVLEVEL)	
		{
			//--- Recover ---
			cntOVPFeedBPhase1++;	

			if(cntOVPFeedBPhase1 > HIGHRECOVERTIME && clearFeed2StatusFSR == 1)	
			{
				cntOVPFeedBPhase1 = 0;	

				FeedBPhaseStatus.bits.PHASE1_V_OV_FAULT = FALSE;
			}
		}
		else
		{
			cntOVPFeedBPhase1 = 0;	
		}
	}
	else
	{
		if(averageVs2[0] > OVLEVEL)	
		{
			//--- FAULT ---
			cntOVPFeedBPhase1++;

			if(cntOVPFeedBPhase1> HIGHLIMITTIME)	
			{
				cntOVPFeedBPhase1 = 0;	

				FeedBPhaseStatus.bits.PHASE1_V_OV_FAULT = TRUE;
				clearFeed2StatusFSR = 0;
			}
		}
		else
		{
			cntOVPFeedBPhase1 = 0;
		}
	}

	//--- FeedB Phase2 OVP FAULT ---
	if(FeedBPhaseStatus.bits.PHASE2_V_OV_FAULT == 1)
	{
		if(averageVs2[1] < OVLEVEL)
		{
			//--- Recover ---
			cntOVPFeedBPhase2++;	

			if(cntOVPFeedBPhase2 > HIGHRECOVERTIME && clearFeed2StatusFSR == 1)	
			{
				cntOVPFeedBPhase2 = 0;	

				FeedBPhaseStatus.bits.PHASE2_V_OV_FAULT = FALSE;
			}
		}
		else
		{
			cntOVPFeedBPhase2 = 0;	
		}
	}
	else
	{
		if(averageVs2[1] > OVLEVEL)	
		{
			//--- FAULT ---
			cntOVPFeedBPhase2++;

			if(cntOVPFeedBPhase2 > HIGHLIMITTIME)	
			{
				cntOVPFeedBPhase2 = 0;	

				FeedBPhaseStatus.bits.PHASE2_V_OV_FAULT = TRUE;
				clearFeed2StatusFSR = 0;
			}
		}
		else
		{
			cntOVPFeedBPhase2 = 0;
		}
	}

	//--- FeedB Phase3 OVP FAULT ---
	if(FeedBPhaseStatus.bits.PHASE3_V_OV_FAULT == 1)
	{
		if(averageVs2[2]  < OVLEVEL)	
		{
			//--- Recover ---
			cntOVPFeedBPhase3++;	

			if(cntOVPFeedBPhase3 > HIGHRECOVERTIME && clearFeed2StatusFSR == 1)	
			{
				cntOVPFeedBPhase3 = 0;	

				FeedBPhaseStatus.bits.PHASE3_V_OV_FAULT = FALSE;
			}
		}
		else
		{
			cntOVPFeedBPhase3 = 0;	
		}
	}
	else
	{
		if(averageVs2[2] > OVLEVEL)	
		{
			//--- FAULT ---
			cntOVPFeedBPhase3++;

			if(cntOVPFeedBPhase3 > HIGHLIMITTIME)	
			{
				cntOVPFeedBPhase3 = 0;	

				FeedBPhaseStatus.bits.PHASE3_V_OV_FAULT = TRUE;
				clearFeed2StatusFSR = 0;
			}
		}
		else
		{
			cntOVPFeedBPhase3 = 0;
		}
	}

	//--- FeedA Phase1 UVP FAULT ---
	if(FeedAPhaseStatus.bits.PHASE1_V_UV_FAULT == 1)
	{
		if(averageVs1[0]  > UVLEVEL && clearFeed1StatusFSR == 1)	
		{
			//--- Recover ---
			cntUVPFeedAPhase1++;

			if(cntUVPFeedAPhase1 > HIGHRECOVERTIME)	
			{
				cntUVPFeedAPhase1= 0;	

				FeedAPhaseStatus.bits.PHASE1_V_UV_FAULT = FALSE;
			}
		}
		else
		{
			cntUVPFeedAPhase1 = 0;	
		}
	}
	else
	{
		if(averageVs1[0] < UVLEVEL)	
		{
			//--- FAULT ---
			cntUVPFeedAPhase1++;

			if(cntUVPFeedAPhase1 > HIGHLIMITTIME)	
			{
				cntUVPFeedAPhase1 = 0;	

				FeedAPhaseStatus.bits.PHASE1_V_UV_FAULT = 1;
				clearFeed1StatusFSR = 0;
			}
		}
		else
		{
			cntUVPFeedAPhase1 = 0;
		}
	}
	
	//--- FeedA Phase2 UVP FAULT ---
	if(FeedAPhaseStatus.bits.PHASE2_V_UV_FAULT)
	{
		if(averageVs1[1] > UVLEVEL && clearFeed1StatusFSR == 1)
		{
			//--- Recover ---
			cntUVPFeedAPhase2++;
				
			if(cntUVPFeedAPhase2> HIGHRECOVERTIME)	
			{
				cntUVPFeedAPhase2 = 0;	
				FeedAPhaseStatus.bits.PHASE2_V_UV_FAULT = FALSE;
			}
		}
		else
		{
			cntUVPFeedAPhase2 = 0;
		}
	}
	else
	{
		if(averageVs1[1] < UVLEVEL)	
		{
			//--- FAULT ---
			cntUVPFeedAPhase2++;

			if(cntUVPFeedAPhase2 > HIGHLIMITTIME)	
			{
				cntUVPFeedAPhase2 = 0;

				FeedAPhaseStatus.bits.PHASE2_V_UV_FAULT = TRUE;
				clearFeed1StatusFSR = 0;
			}
		}
		else
		{
			cntUVPFeedAPhase2 = 0;
		}
	}

	//--- FeedA Phase3 UVP FAULT ---
	if(FeedAPhaseStatus.bits.PHASE3_V_UV_FAULT)
	{
		if(averageVs1[2] > UVLEVEL && clearFeed1StatusFSR == 1)	
		{
			//--- Recover ---
			cntUVPFeedAPhase3++;	

			if( cntUVPFeedAPhase3 > HIGHRECOVERTIME)	
			{
				cntUVPFeedAPhase3 = 0;	

				FeedAPhaseStatus.bits.PHASE3_V_UV_FAULT = FALSE;
			}
		}
		else
		{
			cntUVPFeedAPhase3 = 0;	
		}
	}
	else
	{
		if(averageVs1[2] < UVLEVEL)	
		{
			//--- FAULT ---
			cntUVPFeedAPhase3++;

			if(cntUVPFeedAPhase3 > HIGHLIMITTIME)
			{
				cntUVPFeedAPhase3= 0;

				FeedAPhaseStatus.bits.PHASE3_V_UV_FAULT = TRUE;
				clearFeed1StatusFSR = 0;
			}
		}
		else
		{
			cntUVPFeedAPhase3 = 0;
		}
	}



	//--- FeedB Phase1 UVP FAULT ---
	if(FeedBPhaseStatus.bits.PHASE1_V_UV_FAULT)
	{
		if(averageVs2[0]  > UVLEVEL)	
		{
			//--- Recover ---
			cntUVPFeedBPhase1++;

			if(cntUVPFeedBPhase1 > HIGHRECOVERTIME && clearFeed2StatusFSR == 1)	
			{
				cntUVPFeedBPhase1= 0;

				FeedBPhaseStatus.bits.PHASE1_V_UV_FAULT = FALSE;
			}
		}
		else
		{
			cntUVPFeedBPhase1 = 0;	
		}
	}
	else
	{
		if(averageVs2[0] < UVLEVEL)	
		{
			//--- FAULT ---
			cntUVPFeedBPhase1++;

			if(cntUVPFeedBPhase1 > HIGHLIMITTIME)	
			{
				cntUVPFeedBPhase1 = 0;	

				FeedBPhaseStatus.bits.PHASE1_V_UV_FAULT = TRUE;
				clearFeed2StatusFSR = 0;
			}
		}
		else
		{
			cntUVPFeedBPhase1 = 0;
		}
	}

	//--- FeedB Phase2 UVP FAULT ---
	if(FeedBPhaseStatus.bits.PHASE2_V_UV_FAULT)
	{
		if(averageVs2[1] > UVLEVEL)	
		{
			//--- Recover ---
			cntUVPFeedBPhase2++;	

			if(cntUVPFeedBPhase2 > HIGHRECOVERTIME && clearFeed2StatusFSR == 1)	
			{
				cntUVPFeedBPhase2= 0;	

				FeedBPhaseStatus.bits.PHASE2_V_UV_FAULT = FALSE;
			}
		}
		else
		{
			cntUVPFeedBPhase2 = 0;	
		}
	}
	else
	{
		if(averageVs2[1] < UVLEVEL)	
		{
			//--- FAULT ---
			cntUVPFeedBPhase2++;

			if(cntUVPFeedBPhase2 > HIGHLIMITTIME)	
			{
				cntUVPFeedBPhase2 = 0;	

				FeedBPhaseStatus.bits.PHASE2_V_UV_FAULT = TRUE;
				clearFeed2StatusFSR = 0;
			}
		}
		else
		{
			cntUVPFeedBPhase2 = 0;
		}
	}

	//--- FeedB Phase3 UVP FAULT ---
	if(FeedBPhaseStatus.bits.PHASE3_V_UV_FAULT == 1)
	{
		if(averageVs2[2]  > UVLEVEL)	
		{
			//--- Recover ---
			cntUVPFeedBPhase3++;	

			if(cntUVPFeedBPhase3 > HIGHRECOVERTIME  && clearFeed2StatusFSR == 1)
			{
				cntUVPFeedBPhase3 = 0;

				FeedBPhaseStatus.bits.PHASE3_V_UV_FAULT = FALSE;
			}
		}
		else
		{
			cntUVPFeedBPhase3 = 0;	
		}
	}
	else
	{
		if(averageVs2[2] < UVLEVEL)	
		{
			//--- FAULT ---
			cntUVPFeedBPhase3++;

			if(cntUVPFeedBPhase3 > HIGHLIMITTIME)	
			{
				cntUVPFeedBPhase3 = 0;	

				FeedBPhaseStatus.bits.PHASE3_V_UV_FAULT = TRUE;
				clearFeed2StatusFSR = 0;
			}
		}
		else
		{
			cntUVPFeedBPhase3 = 0;
		}
	}
   StatusFeed1TSR = FeedAPhaseStatus.all;
   StatusFeed2TSR = FeedBPhaseStatus.all;

   if(clearFeed1StatusFSR == 1 && clearFeed2StatusFSR == 0)
   {
	   StatusFeed1TSR = 0;
	   FeedAPhaseStatus.all = FALSE;
	   clearFeed1StatusFSR =0;
   }

   if (clearFeed1StatusFSR == 0 && clearFeed2StatusFSR == 1)
   {
	   StatusFeed2TSR = 0;
	   FeedBPhaseStatus.all = FALSE;
	   clearFeed2StatusFSR =0;
   }
}


void main(){

    /* Clear SYSCFG[STANDBY_INIT] to enable OCP master port */
    CT_CFG.SYSCFG_bit.STANDBY_INIT = 0;

	/* C28 defaults to 0x00000000, we need to set bits 23:8 to 0x0100 in order to have it point to 0x00010000	 */
	PRU0_CTRL.CTPPR0_bit.C28_POINTER = 0x0100;
	
    /* Disable counter */
    CT_IEP.TMR_GLB_CFG_bit.CNT_ENABLE = 0;

    /* Reset Count register */
    CT_IEP.TMR_CNT = 0x0;

    /* Clear overflow status register */
    CT_IEP.TMR_GLB_STS_bit.CNT_OVF = 0x1;

    /* Set compare value */
    CT_IEP.TMR_CMP0 =0x2710 ;//0x2710;//0x4E20;

    /* Clear compare status */
    CT_IEP.TMR_CMP_STS_bit.CMP_HIT = 0xFF;

	/* Disable compensation */
    CT_IEP.TMR_COMPEN_bit.COMPEN_CNT = 0x0;

    /* Enable CMP0 and reset on event */
    CT_IEP.TMR_CMP_CFG_bit.CMP0_RST_CNT_EN = 0x1;
    CT_IEP.TMR_CMP_CFG_bit.CMP_EN = 0x1;

    /* Clear the status of all interrupts */
    CT_INTC.SECR0 = 0xFFFFFFFF;
    CT_INTC.SECR1 = 0xFFFFFFFF;

    /* Enable counter */
    CT_IEP.TMR_GLB_CFG = 0x11;

    initialVariable();
    
    __R30 = 0x00;

    while(1){


    	//__R30 ^= 0x20;


        while ((CT_INTC.SRSR0 & (1 << 7)) == 0);

        CT_INTC.SECR0 = (1 << 7);

        /* Clear Compare status */

        CT_IEP.TMR_CMP_STS = 0xFF;


		readRawValue();

		vacIacIntegration();

		shortTermMaxAvgCal();

		calPower();

		if(enProtect == 1) //aviod starting waste adc value cause UVP
		{
			controlThrottle();
			infoPhaseStatus();
		}
    }

    //==========================================
}




